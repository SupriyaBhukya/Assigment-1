#Arthimatic Operations

number1 = int(input('enter first number:'))
number2 = int(input('enter second number:'))
# Addition of two numbers
print("sum is :", number1 + number2)
#subtraction of two numbers
if (number1 > number2):
    print("subtraction is :",number1-number2)
else:
   print("subtraction is :", number2 - number1)
# multiplication of two numbers
print("multiplication is : ", number1 * number2)
#exponent of two numbers
print("exponent value is :", number1 ** number2)
#Modulus of two numbers
print("modulus value is :", number1 % number2)
