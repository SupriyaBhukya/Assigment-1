#replacing python with pythons

input_value = input("enter the sentence")
result = input_value.replace("python","pythons")
print("modified sentence is:", result)
